# presentation for 8/10
